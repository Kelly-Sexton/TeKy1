function addListItem() {
    var b = $("new-text").val();
    $("#todolist").append('<li> '+b+' <button>Delete</button</li>');
    $("#new-text").val();
}

$(function() {
    $("#add").on('click', addListItem);
});